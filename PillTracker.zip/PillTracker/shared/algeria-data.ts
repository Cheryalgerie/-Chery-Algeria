export const algeriaWilayas = [
  { id: "1", code: "1", name: "Adrar", ar_name: "أدرار" },
  { id: "2", code: "2", name: "Chlef", ar_name: "الشلف" },
  { id: "3", code: "3", name: "Laghouat", ar_name: "الأغواط" },
  { id: "4", code: "4", name: "Oum El Bouaghi", ar_name: "أم البواقي" },
  { id: "5", code: "5", name: "Batna", ar_name: "باتنة" },
  { id: "6", code: "6", name: "Béjaïa", ar_name: "بجاية" },
  { id: "7", code: "7", name: "Biskra", ar_name: "بسكرة" },
  { id: "8", code: "8", name: "Bechar", ar_name: "بشار" },
  { id: "9", code: "9", name: "Blida", ar_name: "البليدة" },
  { id: "10", code: "10", name: "Bouira", ar_name: "البويرة" },
  { id: "11", code: "11", name: "Tamanrasset", ar_name: "تمنراست" },
  { id: "12", code: "12", name: "Tébessa", ar_name: "تبسة" },
  { id: "13", code: "13", name: "Tlemcen", ar_name: "تلمسان" },
  { id: "14", code: "14", name: "Tiaret", ar_name: "تيارت" },
  { id: "15", code: "15", name: "Tizi Ouzou", ar_name: "تيزي وزو" },
  { id: "16", code: "16", name: "Alger", ar_name: "الجزائر" },
  { id: "17", code: "17", name: "Djelfa", ar_name: "الجلفة" },
  { id: "18", code: "18", name: "Jijel", ar_name: "جيجل" },
  { id: "19", code: "19", name: "Sétif", ar_name: "سطيف" },
  { id: "20", code: "20", name: "Saïda", ar_name: "سعيدة" },
  { id: "21", code: "21", name: "Skikda", ar_name: "سكيكدة" },
  { id: "22", code: "22", name: "Sidi Bel Abbès", ar_name: "سيدي بلعباس" },
  { id: "23", code: "23", name: "Annaba", ar_name: "عنابة" },
  { id: "24", code: "24", name: "Guelma", ar_name: "قالمة" },
  { id: "25", code: "25", name: "Constantine", ar_name: "قسنطينة" },
  { id: "26", code: "26", name: "Médéa", ar_name: "المدية" },
  { id: "27", code: "27", name: "Mostaganem", ar_name: "مستغانم" },
  { id: "28", code: "28", name: "M'Sila", ar_name: "المسيلة" },
  { id: "29", code: "29", name: "Mascara", ar_name: "معسكر" },
  { id: "30", code: "30", name: "Ouargla", ar_name: "ورقلة" },
  { id: "31", code: "31", name: "Oran", ar_name: "وهران" },
  { id: "32", code: "32", name: "El Bayadh", ar_name: "البيض" },
  { id: "33", code: "33", name: "Illizi", ar_name: "إليزي" },
  { id: "34", code: "34", name: "Bordj Bou Arréridj", ar_name: "برج بوعريريج" },
  { id: "35", code: "35", name: "Boumerdès", ar_name: "بومرداس" },
  { id: "36", code: "36", name: "El Tarf", ar_name: "الطارف" },
  { id: "37", code: "37", name: "Tindouf", ar_name: "تندوف" },
  { id: "38", code: "38", name: "Tissemsilt", ar_name: "تيسمسيلت" },
  { id: "39", code: "39", name: "El Oued", ar_name: "الوادي" },
  { id: "40", code: "40", name: "Khenchela", ar_name: "خنشلة" },
  { id: "41", code: "41", name: "Souk Ahras", ar_name: "سوق أهراس" },
  { id: "42", code: "42", name: "Tipaza", ar_name: "تيبازة" },
  { id: "43", code: "43", name: "Mila", ar_name: "ميلة" },
  { id: "44", code: "44", name: "Aïn Defla", ar_name: "عين الدفلى" },
  { id: "45", code: "45", name: "Naâma", ar_name: "النعامة" },
  { id: "46", code: "46", name: "Aïn Témouchent", ar_name: "عين تموشنت" },
  { id: "47", code: "47", name: "Ghardaïa", ar_name: "غرداية" },
  { id: "48", code: "48", name: "Relizane", ar_name: "غليزان" },
  { id: "49", code: "49", name: "El Meghaier", ar_name: "المغير" },
  { id: "50", code: "50", name: "El Ménéa", ar_name: "المنيعة" },
  { id: "51", code: "51", name: "Ouled Djellal", ar_name: "أولاد جلال" },
  { id: "52", code: "52", name: "Bordj Badji Mokhtar", ar_name: "برج باجي مختار" },
  { id: "53", code: "53", name: "Béni Abbès", ar_name: "بني عباس" },
  { id: "54", code: "54", name: "Timimoun", ar_name: "تيميمون" },
  { id: "55", code: "55", name: "Touggourt", ar_name: "تقرت" },
  { id: "56", code: "56", name: "Djanet", ar_name: "جانت" },
  { id: "57", code: "57", name: "In Salah", ar_name: "عين صالح" },
  { id: "58", code: "58", name: "In Guezzam", ar_name: "عين قزام" }
];

// البلديات الرئيسية لكل ولاية (عينة من البلديات المهمة)
export const algeriaCommunesByWilaya: Record<string, string[]> = {
  "16": [ // الجزائر
    "Alger Centre", "Bab El Oued", "El Harrach", "Hussein Dey", "Kouba", "Bir Mourad Raïs",
    "Dar El Beïda", "El Mouradia", "Birkhadem", "Cheraga", "Draria", "Zeralda",
    "Ouled Fayet", "Sidi Moussa", "Rahmania", "Souidania", "Staoueli", "Ain Benian"
  ],
  "31": [ // وهران
    "Oran", "Bir El Djir", "Es Senia", "Arzew", "Bethioua", "Ain El Turck", "Mers El Kebir",
    "Boutlelis", "El Braya", "Hassi Bounif", "Hassi Mefsoukh", "Sidi Chami", "Gdyel"
  ],
  "25": [ // قسنطينة
    "Constantine", "El Khroub", "Ain Smara", "Didouche Mourad", "Hamma Bouziane", "Ibn Ziad",
    "Messaoud Boudjeriou", "Ouled Rahmoun", "Zighoud Youcef", "Ain Abid"
  ],
  "19": [ // سطيف
    "Sétif", "El Eulma", "Ain Kebira", "Bougaa", "Ain Oulmene", "Salah Bey", "Mezloug",
    "Bir Haddada", "Babor", "Guidjel", "Hammam Sokhna", "Rasfa"
  ],
  "9": [ // البليدة
    "Blida", "Boufarik", "Larbaa", "Bougara", "El Affroun", "Mouzaia", "Soumaa", "Ouled Yaich",
    "Chrea", "Bouinan", "Beni Mered", "Meftah", "Hammam Melouane"
  ],
  "6": [ // بجاية
    "Béjaïa", "Akbou", "Kherrata", "Sidi Aich", "El Kseur", "Amizour", "Tazmalt", "Tichy",
    "Aokas", "Souk El Tenine", "Darguina", "Ighram", "Seddouk"
  ],
  "15": [ // تيزي وزو
    "Tizi Ouzou", "Azazga", "Draa El Mizan", "Larbaâ Nath Irathen", "Tigzirt", "Azeffoun",
    "Ain El Hammam", "Makouda", "Ouaguenoun", "Boghni", "Freha", "Mekla"
  ],
  "35": [ // بومرداس
    "Boumerdès", "Dellys", "Naciria", "Baghlia", "Khemis El Khechna", "Boudouaou",
    "Corso", "Ouled Moussa", "Si Mustapha", "Zemmouri", "Bordj Menaiel"
  ],
  "42": [ // تيبازة
    "Tipaza", "Koléa", "Cherchell", "Hadjout", "Menaceur", "Larhat", "Douaouda",
    "Fouka", "Bou Ismail", "Chiffa", "Meurad", "Ahmer El Ain"
  ],
  "44": [ // عين الدفلى
    "Aïn Defla", "Khemis Miliana", "El Attaf", "El Abadia", "Djendel", "Boumedfaa",
    "Miliana", "Tiberkanine", "Hammam Righa", "Bir Ould Khelifa"
  ],
  "26": [ // المدية
    "Médéa", "Berrouaghia", "Ksar El Boukhari", "Ouamri", "Si Mahdjoub", "Ouzera",
    "Ain Boucif", "Aziz", "Boughezoul", "Chellalet El Adhaoura"
  ],
  "10": [ // البويرة
    "Bouira", "Lakhdaria", "M'Chedallah", "Sour El Ghouzlane", "Kadiria", "Bir Ghbalou",
    "Bordj Okhriss", "El Hachimia", "Ain Bessem", "Bechloul"
  ],
  "28": [ // المسيلة
    "M'Sila", "Bou Saâda", "Djelfa", "Sidi Aissa", "Magra", "Berhoum", "Hammam Dalaa",
    "Ouled Derraj", "Ain El Melh", "Khoubana"
  ],
  "17": [ // الجلفة
    "Djelfa", "Messaad", "Ain Oussera", "Birine", "Sidi Ladjel", "El Idrissia",
    "Hassi Bahbah", "Moudjbara", "Faidh El Botma", "Dar Chioukh"
  ],
  "3": [ // الأغواط
    "Laghouat", "Aflou", "Ksar El Hirane", "Ain Madhi", "Oued Morra", "Gueltat Sidi Saad",
    "Brida", "El Assafia", "Hassi Delaa", "Sidi Makhlouf"
  ],
  "32": [ // البيض
    "El Bayadh", "Rogassa", "Stitten", "Brezina", "Boualem", "El Abiodh Sidi Cheikh",
    "Ain El Orak", "Arbaouat", "Kef El Ahmar", "Tousmouline"
  ],
  "8": [ // بشار
    "Béchar", "Abadla", "Beni Ounif", "Kenadsa", "Lahmar", "Ouled Khodeir",
    "Boukais", "Mogheul", "Meridja", "Tabelbala"
  ],
  "37": [ // تندوف
    "Tindouf", "Oum El Assel", "Hassi El Ghella"
  ],
  "1": [ // أدرار
    "Adrar", "Reggane", "In Salah", "Timimoun", "Aoulef", "Tsabit", "Fenoughil",
    "Tamest", "Tinerkouk", "Deldoul", "Charouine", "Sebaa"
  ],
  "47": [ // غرداية
    "Ghardaïa", "El Menia", "Berriane", "Metlili", "El Guerrara", "Mansoura",
    "Hassi Lefhal", "Hassi Gara", "Zelfana", "Sebseb"
  ],
  "30": [ // ورقلة
    "Ouargla", "Touggourt", "Hassi Messaoud", "Temacine", "Megarine", "Djamaa",
    "El Hadjira", "Taibet", "Ngoussa", "El Borma"
  ],
  "39": [ // الوادي
    "El Oued", "Guemar", "Debila", "Reguiba", "Magrane", "Still", "Taghzout",
    "Hassi Khelifa", "Trifaoui", "Jamaa"
  ],
  "33": [ // إليزي
    "Illizi", "Djanet", "In Amenas", "Debdeb", "Bordj El Haoues"
  ],
  "11": [ // تمنراست
    "Tamanrasset", "In Guezzam", "In Salah", "Tin Zaouatine", "Idles", "Tazrouk"
  ]
};

export type Wilaya = {
  id: string;
  code: string;
  name: string;
  ar_name: string;
};

export type OrderFormData = {
  firstName: string;
  lastName: string;
  phone: string;
  wilayaId: string;
  commune: string;
  address: string;
  productId: string;
  selectedSize: string;
  quantity: number;
};